import os, random

def FileRead(fp):
    with open(fp, "rb") as f:
        data = f.read()
        print("File Read: {} -> {} bytes".format(fp, len(data)))
        return data
    
def RandomBytes(n):
    r = bytes()
    for i in range(0, n):
        r += (random.randrange(0, 2**8)).to_bytes(1, "big")
    return r

def Enc(key, pt):
    pt = int.from_bytes(pt, 'big')
    key = int.from_bytes(key, 'big')
    res = P(pt ^ key) ^ key
    return res.to_bytes(5, 'big')

def BytesXOR(x, y):
    assert len(x) == len(y)
    n = len(x)
    z = bytes()
    for i in range(0, n):
        z += (x[i]^y[i]).to_bytes(1, "big")
    return z

def BytesToBits(x):
    assert type(x) == bytes
    n = len(x)
    y = list()
    for i in range(0, n):
        for j in range(0, 8):
            y.append((x[i]&(1<<(7-j)))>>(7-j))
    return y

def BitsToBytes(x):
    assert type(x) == list
    n = len(x)
    assert n%8 == 0
    n = n//8
    y = bytes()
    for i in range(0, n):
        s = 0
        for j in range(0, 8):
            s += x[8*i+j]*(1<<(7-j))
        y += s.to_bytes(1, "big")
    return y