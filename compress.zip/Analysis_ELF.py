import sys

sys.path.append("C:\\Users\\SEC\\Downloads\\jupyter_works\\lib")
from Base import *

sys.path.append("C:\\Program Files\\Python35\\Lib\\site-packages")
from capstone import *

dict_architecture = {
    b'\x00\x00': "null", 
    b'\x02\x00': "SPARC", 
    b'\x03\x00': "x86", 
    b'\x08\x00': "MIPS",
    b'\x14\x00': "PowerPC", 
    b'\x28\x00': "ARM", 
    b'\x32\x00': "IA-64", 
    b'\x3e\x00': "x86-64", 
}

form_file_header = [
    ["magic_number", 4, {b'\x7fELF': "Executable and Linkable Format"}],
    ["address_bits", 1, {b'\x01': "32bit", b'\x02': "64bit"}],
    ["endian", 1, {b'\x01': "little", b'\x02': "big"}],
    ["version", 1, "integer"],
    ["ABI", 1, {b'\x00': "System V"}],
    ["ABI_version", 1, "integer"],
    ["not_used", 7, "byte"],
    ["type", 2, {b'\x01\x00': "reallocate", b'\x02\x00': "executable", b'\x03\x00': "share", b'\x04\x00': "core"}],
    ["architecture", 2, dict_architecture],
    ["version", 4, "integer"],
    ["entry_point", "address", "integer"],
    ["offset_program_header", "address", "integer"],
    ["offset_section_header", "address", "integer"],
    ["flag", 4, "byte"],
    ["file_header_size", 2, "integer"],
    ["p_header_entry_size", 2, "integer"],
    ["p_header_entry_num", 2, "integer"],
    ["s_header_entry_size", 2, "integer"],
    ["s_header_entry_num", 2, "integer"],
    ["section_names_index", 2, "integer"],
]

dict_section_type = {
    b'\x00\x00\x00\x00': "NULL", 
    b'\x01\x00\x00\x00': "PROGBITS",
    b'\x02\x00\x00\x00': "SYMTAB",# 	Symbol table
    b'\x03\x00\x00\x00': "STRTAB",# 	String table
    b'\x04\x00\x00\x00': "RELA",# 	Relocation entries with addends
    b'\x05\x00\x00\x00': "HASH",# 	Symbol hash table
    b'\x06\x00\x00\x00': "DYNAMIC",# 	Dynamic linking information
    b'\x07\x00\x00\x00': "NOTE",# 	Notes
    b'\x08\x00\x00\x00': "NOBITS",# 	Program space with no data (bss)
    b'\x09\x00\x00\x00': "REL",#	Relocation entries, no addends
    b'\x0a\x00\x00\x00': "SHLIB",# 	Reserved
    b'\x0b\x00\x00\x00': "DYNSYM",# 	Dynamic linker symbol table
    b'\x0e\x00\x00\x00': "INIT_ARRAY",# 	Array of constructors
    b'\x0f\x00\x00\x00': "FINI_ARRAY",# 	Array of destructors
    b'\x10\x00\x00\x00': "PREINIT_ARRAY",# 	Array of pre-constructors
    b'\x11\x00\x00\x00': "GROUP",# 	Section group
    b'\x12\x00\x00\x00': "SYMTAB_SHNDX",# 	Extended section indices
    b'\xf6\xff\xffo': "UNKNOWN",
    b'\xfd\xff\xffo': "GNU_verdef",
    b'\xfe\xff\xffo': "GNU_verneed",
    b'\xff\xff\xffo': "GNU_versym",
}

form_section_header_entry = [
    ["name", 4, "integer"],
    ["type", 4, dict_section_type],
    ["flag", "address", "byte"],
    ["virtual_address", "address", "integer"],
    ["offset", "address", "integer"],
    ["size", "address", "integer"],
    ["link", 4, "integer"],
    ["info", 4, "byte"],
    ["alignment", "address", "integer"],
    ["entry_size", "address", "integer"]
]

dict_segment_type = {
    b'\x00\x00\x00\x00': "NULL", 
    b'\x01\x00\x00\x00': "LOAD", 
    b'\x02\x00\x00\x00': "DYNAMIC", 
    b'\x03\x00\x00\x00': "INTERP", 
    b'\x04\x00\x00\x00': "NOTE", 
    b'\x05\x00\x00\x00': "SHLIB", 
    b'\x06\x00\x00\x00': "PHDR", 
    b'\x00\x00\x00\x60': "LOOS", 
    b'\xff\xff\xff\x6f': "HIOS", 
    b'\x00\x00\x00\x70': "LOPROC", 
    b'\xff\xff\xff\x7f': "HIPROC",
    b'Q\xe5td': "GNU_EH_FRAME",
    b'P\xe5td': "GNU_STACK",
    b'R\xe5td': "GNU_RELRO",
    b'S\xe5td': "GNU_HEAP",
}
    
form_program_header_entry = [
    ["type", 4, dict_segment_type],
    ["flag", "64bit", "byte"],
    ["offset", "address", "integer"],
    ["virtual_address", "address", "integer"],
    ["physical_address", "address", "integer"],
    ["size_in_file", "address", "integer"],
    ["size_in_memory", "address", "integer"],
    ["flag", "32bit", "byte"],
    ["alignment", "address", "integer"],
]

dict_symbol_type = {
    b'\x00': "local no-type",
    b'\x01': "local data object",
    b'\x02': "local function",
    b'\x03': "local section",
    b'\x04': "source file name",
    b'\x10': "global no-type",
    b'\x11': "global data object",
    b'\x12': "global function",
    b'\x20': "weak no-type",
}

form_symbol_table_entry = [
    ["name", 4, "integer"],
    ["address", 4, "integer"],
    ["size", 4, "integer"],
    ["type", 1, dict_symbol_type],
    ["not_used", 1, "byte"],
    ["section_index", 2, "integer"],    
]

form_relocation_entry = [
    ["address", 4, "integer"],
    ["type", 1, dict_symbol_type],
    ["symbol_index", 3, "integer"],
]

def ShowHex(data, offset=0, size=1024):
    index = offset
    end = offset + size
    while index < end and index < len(data):
        temp = data[index:index+16]
        str_hex = str(); str_ascii = str()
        for byte in temp:
            str_hex += "{:02x} ".format(byte)
            str_ascii += "{:c}".format(byte) if 32 < byte < 127 else "."
        print("{:08x}: {:48} {:18}".format(index, str_hex, str_ascii))
        index += 16
        
def ShowAssembly(code, offset=0, arch=CS_ARCH_X86, address_bits=CS_MODE_32):
    capst = Cs(arch, address_bits)
    for i in capst.disasm(code, 0):
        print("0x{:08x}: {:<16} {:4} {}".format(i.address, bytes(i.bytes).hex(), i.mnemonic, i.op_str))    

class ELF:
    def __init__(self, data):
        if type(data) == str:
            self.fp_in = data
            self.data = FileRead(self.fp_in)
        else:
            self.fp_in = None
            self.data = data
        assert self.data[0:4] == b'\x7fELF'
        assert self.data[4] in [1, 2]
        self.address_bits = "64bit" if self.data[4] == 2 else "32bit"
        assert self.data[5] in [1, 2]
        self.endian = "big" if self.data[5] == 2 else "little"
        
        self.file_header = self.Parse(form_file_header, self.data)
        ShowHex(self.data, 0, self.file_header["file_header_size"][1])
        self.architecture = self.file_header["architecture"][1]
        assert self.architecture in ["x86", "x86-64"]
        self.ShowFileHeader()

    def Parse(self, form, data, offset=0):
        result = dict()
        index = offset
        for item in form:
            ### find length
            if item[1] == "address":
                length = 4 if self.address_bits == "32bit" else 8
            elif item[1] == "64bit":
                length = 0 if self.address_bits == "32bit" else 4
            elif item[1] == "32bit":
                length = 4 if self.address_bits == "32bit" else 0
            else:
                length = item[1]
            temp = data[index:index+length]; index += length
            ### evaluate
            if type(item[2]) == dict:
                value = item[2][temp]
            elif item[2] == "integer":
                value = int.from_bytes(temp, self.endian)
            else:
                value = temp
            result[item[0]] = [temp, value]
        ## print result
        #print("from {} to {}, read {} bytes".format(offset, index, index - offset))
        #print("-"*120)
        #for key, value in result.items():
        #    if key not in ["not_used", "address_bits", "endian"]:
        #        print("{0:>24}: {2:}".format(key, *value))
        return result
        
    def ShowFileHeader(self):
        print("-"*75 + "\nELF File Header\n" + "-"*75)
        for name, value in self.file_header.items():
            print("{0:>32}: \033[1;31m{2}\033[0m".format(name, *value))
    
    def GetSegments(self):
        offset = self.file_header["offset_program_header"][1]
        num = self.file_header["p_header_entry_num"][1]
        unit = self.file_header["p_header_entry_size"][1]
        size = num*unit
        self.segments = list()
        for i in range(0, num):
            segment = self.Parse(form_program_header_entry, self.data, offset+i*unit)
            segment["data"] = [self.data[segment["offset"][1]:segment["offset"][1]+segment["size_in_file"][1]]]
            self.segments.append(segment)
        print("{} segments".format(len(self.segments)))
        for segment in self.segments:
            print("-"*75)
            print("{type[1]:16} {size_in_file[1]:>8}\t0x{virtual_address[1]:08x}\t0x{physical_address[1]:08x}\n".format(**segment))
            ShowHex(segment["data"][0])
        
    def GetSections(self):
        offset = self.file_header["offset_section_header"][1]
        num = self.file_header["s_header_entry_num"][1]
        unit = self.file_header["s_header_entry_size"][1]
        size = num*unit
        section_names_index = self.file_header["section_names_index"][1]
        self.sections = list()
        for i in range(0, num):
            section_entry = self.Parse(form_section_header_entry, self.data, offset+i*unit)
            temp = self.data[section_entry["offset"][1]:section_entry["offset"][1]+section_entry["size"][1]]
            section_entry["data"] = [temp] 
            self.sections.append(section_entry)
        section_names = self.sections[section_names_index]["data"][0]
        for section in self.sections:
            name = str()
            index = section["name"][1]
            while section_names[index] != 0:
                name += chr(section_names[index])
                index += 1
            section["name"][1] = name
        print("{} sections".format(len(self.sections)))
        for i in range(0, len(self.sections)):
            section = self.sections[i]
            print("-"*75)
            print("[{:02}]\033[1;31m{name[1]:18}\033[0m {type[1]:12} {offset[1]:>8} {size[1]:>8} {entry_size[1]:>4}\t0x{virtual_address[1]:08x}\n".format(i, **section))
            ShowHex(section["data"][0])
    
    def GetSectionIndex(self, name):
        n = len(self.sections)
        for i in range(0, n):
            if self.sections[i]["name"][1] == name:
                return i        
        return 0
    
    def GetString(self, data, index):
        assert type(data) == bytes
        string = str()
        while data[index] != 0:
            string += chr(data[index])
            index += 1
        return string
    
    def GetSymbols(self):
        index = self.GetSectionIndex(".symtab")
        symtab_data = self.sections[index]["data"][0]
        entry_size = self.sections[index]["entry_size"][1]
        total_size = self.sections[index]["size"][1]
        num = total_size//entry_size
        print("{} symbols".format(num))
        self.symbols = list()
        for i in range(0, num):
            offset = i*entry_size
            symbol = self.Parse(form_symbol_table_entry, symtab_data, offset)
            self.symbols.append(symbol)
        index = self.GetSectionIndex(".strtab")
        symbol_names = self.sections[index]["data"][0]
        for symbol in self.symbols:
            if symbol["name"][1] != 0:
                name = self.GetString(symbol_names, symbol["name"][1])
                symbol["name"][1] = name
            elif symbol["type"][0] == b'\x03':
                symbol["name"][1] = self.sections[symbol["section_index"][1]]["name"][1]
            else:
                symbol["name"][1] = ""
        #Show symbols
        for symbol in self.symbols:
            print("-"*120)
            print("{type[1]:24} \033[1;31m{name[1]:32}\033[0m in section {section_index[1]:>5} from {address[1]:>8} of size {size[1]:>6}\n".format(**symbol))
            if "function" in symbol["type"][1]:
                start = symbol["address"][1]
                size = symbol["size"][1]
                code = self.sections[symbol["section_index"][1]]["data"][0][start:start+size]
                ShowAssembly(code)
            elif "data" in symbol["type"][1] and symbol["section_index"][1] < len(self.sections):
                start = symbol["address"][1]
                size = symbol["size"][1]
                print(self.sections[symbol["section_index"][1]]["data"][0][start:start+size])